var $kernel = require('ku4node-kernel'),
    $ = $kernel.asserters,
    $lyrics = require('../../../lib/model/capabilities/lyrics'),
    lyrics = $lyrics();

exports['create'] = function (test) {
    test.expect(1);
    var lyrics = $lyrics();
    test.ok(lyrics);
    test.done();
};

exports['addIntro'] = function (test) {
    test.expect(2);

    var intro1 = "Intro 1",
        intro2 = "intro 2";

    lyrics
        .addIntro(intro1)
        .addIntro(intro2);

    test.equal(lyrics.nextIntro(), intro1, "intro1");
    test.equal(lyrics.nextIntro(), intro2, "intro2");

    test.done();
};