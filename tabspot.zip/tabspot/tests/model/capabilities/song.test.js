var $kernel = require('ku4node-kernel'),
    $ = $kernel.asserters,
    $song = require('../../../lib/model/capabilities/song');

exports['create'] = function (test) {
    test.expect(1);
    var song = $song();
    test.ok(song);
    test.done();
};

exports['properties'] = function (test) {
    test.expect(1);
    var song = $song(),
        title = "myTitle";

    song.title(title);
    test.equal(title, song.title(), "title");

    test.done();
};