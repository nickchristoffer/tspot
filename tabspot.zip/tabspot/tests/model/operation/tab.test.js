var $kernel = require('ku4node-kernel'),
    $ = $kernel.asserters,
    $tab = require('../../../lib/model/operation/tab');

exports['create'] = function (test) {
    test.expect(1);
    var tab = $tab();
    test.ok(tab);
    test.done();
};

exports['properties'] = function (test) {
    test.expect(0);
    var tab = $tab(),
        name = "myTab";

    //tab.name(name);
    //test.equal(name, tab.name(), "name");

    test.done();
};